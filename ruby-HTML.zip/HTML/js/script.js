
function myFunction(x) {
    x.classList.toggle("change");
    jQuery("header").toggleClass("header-bg");
}


/* back to top */
jQuery(document).ready(function(){
	jQuery( '.back-to-top-inner').click( function(e) {	
		jQuery('#modal-table').animate({ scrollTop: 0 }, 'slow');
		e.preventDefault();
	});
 });

	

/* tolltip */
jQuery(document).ready(function(){
    /* custom flatpiker date */
    flatpickr('.calendar',{ dateFormat: 'd/m/Y'});  
});

